// script.js - petit script pour confirmation
document.addEventListener('DOMContentLoaded', function(){
  const form = document.getElementById('contactForm');
  form.addEventListener('submit', function(){
    // simple feedback; Formspree fera l'envoi
    alert('Merci ! Votre demande a été envoyée. Nous vous répondrons bientôt.');
  });
});