
# DKT-AFFERMAGE - Site statique (GitHub Pages)

Contenu: site simple pour location de Toyota Land Cruiser & Hilux.

## Fichiers
- `index.html` - page principale
- `style.css` - styles
- `script.js` - petit script client
- `CNAME` - nom de domaine personnalisé
- `README.md` - ceci

## Personnalisation rapide
- Remplace les images dans `index.html` par tes propres photos (modifier les `src`).
- Change le texte (titre, description, coordonnées) directement dans `index.html`.
- Pour que le formulaire envoie des emails automatiquement : inscris-toi sur https://formspree.io et remplace `action` du formulaire par ton endpoint Formspree (ex: https://formspree.io/f/xxxxx).

## Déployer sur GitHub Pages
1. Crée un dépôt GitHub (par ex. `dkt-affermage`).
2. Pousse les fichiers à la branche `main` (ou `gh-pages` si tu préfères).
3. Dans les Settings du dépôt → Pages: choisis la branche `main` et le dossier `/ (root)`.
4. Ajoute un fichier `CNAME` (déjà inclus) contenant: `www.dkt-affermage.com`.
5. DNS: dans le panneau de ton registrar, configure:
   - Un enregistrement **A** pour `@` pointant vers ces IPs GitHub Pages (ex:)
     - 185.199.108.153
     - 185.199.109.153
     - 185.199.110.153
     - 185.199.111.153
   - Et un enregistrement **CNAME** pour `www` pointant vers: `USERNAME.github.io` (remplace USERNAME par ton pseudo GitHub).
6. Attends la propagation DNS (quelques minutes à quelques heures).
7. Dans GitHub Pages, active HTTPS (si disponible).

## Notes
- Les images utilisées sont des images libres de Unsplash via URL; remplace-les par tes propres photos si tu veux.
- Si tu veux que je te guide pour chaque étape (création du dépôt, push, configuration DNS), dis-le et je t'expliquerai pas à pas.
